﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
    　/*右端で止める*/
        if(transform.position.x < 8.0f){
            if(Input.GetKey(KeyCode.LeftArrow)){
                this.transform.Translate(0.5f, 0.0f, 0.0f);
            }
        }
    
    /*左端で止める*/    
        if(transform.position.x > -8.0f){
            if(Input.GetKey(KeyCode.RightArrow)){
                this.transform.Translate(-0.5f, 0.0f, 0.0f);
            }
        }
        
    }
}
