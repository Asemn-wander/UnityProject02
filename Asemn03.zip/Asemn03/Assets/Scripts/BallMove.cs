﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallMove : MonoBehaviour
{

    public Rigidbody rb;
    
    // Start is called before the first frame update
    void Start()
    {
        rb.AddForce(20, 0, 250, ForceMode.Impulse); //瞬間的に力を加える
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
